First, make sure to install xampp server 
you can install any version

After extracting the zip file, keep the file in htdocs

Now open xampp control panel and start apache

How to open website in browser:
Type localhost/techpro/index.html

THANKS !!!!!


